(self.__BUILD_MANIFEST = {
  __rewrites: { afterFiles: [], beforeFiles: [], fallback: [] },
  "/_error": ["static/chunks/pages/_error-d6107f1aac0c574c.js"],
  sortedPages: ["/_app", "/_error"],
}),
  self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB();
